package client;

import service.BanqueService;
import service.BanqueServiceService;
import service.Compte;
import java.util.List;

public class ClientWS {
    public static void main(String[] args) {
        // Create service instance
        BanqueServiceService serviceService = new BanqueServiceService();
        BanqueService banqueService = serviceService.getBanqueServicePort();

        System.out.println("=== Testing Web Service Client ===");

        // Test conversion
        double result = banqueService.conversion(100);
        System.out.println("Conversion 100 EUR = " + result + " USD");

        // Test getCompte
        Compte compte = banqueService.getCompte(123);
        System.out.println("Compte details - Code: " + compte.getCode() + ", Solde: " + compte.getSolde());

        // Test getComptes
        List<Compte> comptes = banqueService.getComptes();
        System.out.println("List of comptes:");
        for (Compte c : comptes) {
            System.out.println("  - Code: " + c.getCode() + ", Solde: " + c.getSolde());
        }
    }
}

